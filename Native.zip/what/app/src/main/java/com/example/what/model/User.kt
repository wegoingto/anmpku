package com.example.what.model

data class User(
    val username: String,
    val password: String
)