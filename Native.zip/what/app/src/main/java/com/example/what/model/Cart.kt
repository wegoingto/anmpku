package com.example.what.model

data class Cart(
    var menu: Menu,
    var qty: Int
);