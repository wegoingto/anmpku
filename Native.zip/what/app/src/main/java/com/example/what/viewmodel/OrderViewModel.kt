package com.example.what.viewmodel

import androidx.lifecycle.ViewModel

class OrderViewModel : ViewModel() {

}